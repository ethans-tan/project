import java.util.Random;

public class Beetle extends Insect{
	
	private static final int MAX_AGE = 40;
	private static final int MAX_CAP = 40;
	
	private int stomach;
	
	public Beetle(int initialX, int initialY) {
		super(0, initialX, initialY);
		stomach = MAX_CAP;
	}
	
	@Override
	public void move() {
		
		int newX = getX();
		int newY = getY();
		
		int currentAge = getAge();
		setAge(currentAge + 1);
		
		//Choose a direction to move (0 - 4)
		Random rand = new Random();
		int moveDirection = rand.nextInt(5);
		
		if(moveDirection == 1) {
			newY--;
			
		}
		else if (moveDirection == 2){
			newY++;
		}
		else if (moveDirection == 3) {
			newX--;
			
		}
		else if (moveDirection == 4) {
			newX++;
		}
		
		if (newX >= 0 && newX < InsectSimulation.getAreaWidth() &&
	            newY >= 0 && newY < InsectSimulation.getAreaHeight()) {
	            Insect insectAtNewPosition = InsectSimulation.getInsectAt(newX, newY);
	            if (insectAtNewPosition == null) {
	                InsectSimulation.moveInsect(this, newX, newY);
	            } else if (insectAtNewPosition instanceof Aphid) {
	                eatAphid((Aphid) insectAtNewPosition);
	            }
	        }
	    }

	private void eatAphid(Aphid aphid) {
		InsectSimulation.removeInsect(aphid);
	    stomach += 5 + new Random().nextInt(6); // Random value between 5 and 10
	}
	
	public boolean isDead() {
		return getAge() > MAX_AGE || stomach <= 0;
	}
	
	public boolean reproduce() {
		
		if (stomach > MAX_CAP * 0.8) {
            int[] newPosition = InsectSimulation.findEmptyAdjacentPosition(getXPosition(), getYPosition());

            if (newPosition != null) {
                InsectSimulation.addInsect(new Beetle(newPosition[0], newPosition[1], stomach / 2));
                stomach /= 2; // Share half of the stomach with the child
                return true;
            }
        }
        return false;
	}
	    
	
	
	
}
