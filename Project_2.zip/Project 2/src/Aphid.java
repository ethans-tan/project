import java.util.Random;

public class Aphid extends Insect {

	private static final int MAX_AGE = 15;
	
	//constructor
	public Aphid(int x, int y) {
		super(0,x,y);
	}
	
	@Override
	public void move() {
		
		int newX = getX();
		int newY = getY();
		
		int currentAge = getAge();
		setAge(currentAge + 1);
		
		//Choose a direction to move (0 - 4)
		Random rand = new Random();
		int moveDirection = rand.nextInt(5);
		
		if(moveDirection == 1) {
			newY--;
			
		}
		else if (moveDirection == 2){
			newY++;
		}
		else if (moveDirection == 3) {
			newX--;
			
		}
		else if (moveDirection == 4) {
			newX++;
		}
		
		//check to see if the move is within bounds
		
		if((newX >= 0 && newX < InsectSimulation.getAreaWidth()) && (newY >= 0 && newY < InsectSimulation.getAreaHeight()) && (InsectSimulation.getInsectAt(newX, newY) == null)) {
			InsectSimulation.moveInsect(this, newX, newY);
			
		}
		
	}
	
	@Override
	public boolean isDead() {
		return getAge() > MAX_AGE;
	}
	
	@Override
	public boolean reproduce() {
		
		if(getAge() % 5 == 0) {
		
			int[] newPosition = InsectSimulation.findEmptyAdjacentPosition(getX(), getY());
			
			if (newPosition != null) {
                InsectSimulation.addInsect(new Aphid(newPosition[0], newPosition[1]));
                return true;
            }
        }
        return false;
	}
}




