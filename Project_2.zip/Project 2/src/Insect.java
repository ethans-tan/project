public abstract class Insect {

	private int age;
	private int xPosition;
	private int yPosition;
	
	//Constructor
	public Insect(int initialAge, int initialX, int initialY) {
		age = initialAge;
		xPosition = initialX;
		yPosition = initialY;
	}
	
	//Abstract methods
	public abstract void move();
	
	public abstract boolean isDead();
	
	public abstract boolean reproduce();
	
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int a) {
		age = a;
		
	}
	
	public int getX() {
		return xPosition;
		
	}
	
	public int getY() {
		return yPosition;
		
	}
	
	public void setPosition(int x, int y) {
		xPosition = x;
		yPosition = y;
	}
	
}
